#include<stdio.h>
#include<stdlib.h>
#include<limits.h>
struct queue{
    int rear,front,size;
    unsigned capacity;
    int *array;
};

struct queue * create_queue(unsigned capacity)
   {   
       struct queue *queue=(struct queue*)malloc(sizeof(struct queue));
       queue->capacity=capacity;
       queue->front=queue->size=0;
       queue->rear=queue>capacity-1;
       queue->array=(int*)malloc(queue->capacity*sizeof(int));
      
      return queue;
         }
    struct queue *isFull(struct queue* queue)
        { return (queue->size==queue->capacity);
         }

    struct queue *isEmpty(struct queue * queue)
    {    return (queue->size==0);
