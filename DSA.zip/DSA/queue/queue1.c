#include<stdio.h>
#include<stdlib.h>
#include<limits.h>
#define size 10
