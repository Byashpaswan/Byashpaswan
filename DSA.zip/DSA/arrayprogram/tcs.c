#include<stdio.h>
int main()
{
    int arr[]={1,2,4,5,7,8};
    int n=sizeof(arr)/sizeof(arr[0]);
    int sum=0;
    for(int i=0;i<n;i+=2)
    { 
         sum=arr[i]+arr[i+1];

        for(int j=0;j<(n/2)-1;j--)
           { arr[n-1-j]= sum;
            break;
           }
        
    }

    for(int i=0;i<6;i++)
       printf("%d", arr[i]);

}