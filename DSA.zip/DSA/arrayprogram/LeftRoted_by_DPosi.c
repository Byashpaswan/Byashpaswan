#include<stdio.h>
#include<conio.h>
void Rotate(int arr[],int d,int n)
{
    int temp[n];
    int k=0;
    //copy n-d element in temp arr
    for(int i=d;i<n;i++)
    { temp[k]=arr[i];
      k++;

    }
    // storing first d element in temp
    for(int i=0;i<d;i++)
    {
        temp[k]=arr[i];
        k++;
    }

    // coping element to arr from temp
    for(int i=0;i<n;i++)
    {
        arr[i]=temp[i];
    }

}

void printArray(int arr[],int n)
{
    for(int i=0;i<n;i++)
      printf("%d ", arr[i]);
}
int main()
{ int arr[]={1,2,3,4,5,6,7};
 int n=sizeof(arr)/sizeof(arr[0]);
 Rotate(arr,3,n);
 printArray(arr,n);

}