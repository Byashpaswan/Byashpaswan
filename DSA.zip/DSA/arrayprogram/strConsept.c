#include<stdio.h>
#include<string.h>
int main()
{ int l;
 char str[20]="Byas Paswan";
 strrev(str);
 l=strlen(str);
 printf("%d\n %s",l,str);
}