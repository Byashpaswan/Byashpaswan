#define LEFT 0
#define RIGHT 1
#include<stdio.h>
void display(int[],int N);
void rotetarray(int arr[],int N,int dir,int shift_count);
int main()
{ int arr[]={10,20,30,40,50,60,70,80};
display(arr,8);
rotetarray(arr,8,LEFT,3);
display(arr,8);
}
void display(int arr[],int N)
{ int i;
  printf("\n"); 
  for(i=0;i<N;i++)
     printf("%d ",arr[i]);
   }
void rotetarray(int arr[],int N,int dir,int shift_count)
  { int temp,i;
    if(dir==LEFT)
    { while(shift_count)
       { temp=arr[N-1];
         for(i=N-1;i>=1;i--)
            arr[i]=arr[i-1];
         arr[0]=temp;
         shift_count--;
        }
      }
    else
       { while(shift_count)
          { temp=arr[0];
            for(i=0;i<=N-2;i++)
                arr[i]=arr[i+1];
            arr[N-1]=temp;
            shift_count--;
          }
       }
  }