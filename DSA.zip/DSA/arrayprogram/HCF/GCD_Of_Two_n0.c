#include<stdio.h>
int main()
{   // gratest comman devisor jo do ko divide kar de 
    int a,b, min, highComnf,Lcm;
    printf("Enter two no that u want to check b/n two no of HCG and LCm :");
    scanf("%d %d",&a,&b);
    min=a>b?a:b;
    for(int i=1;i<=min;i++)
    {
        if(a%i==0 && b%i==0)
        highComnf=i;
    }
   Lcm=(a*b)/highComnf;

    printf(" The Hcf of %d and %d  is %d",a,b,highComnf );
    printf("\n");
     printf(" The LCM of %d and %d  is %d",a,b,Lcm );
}