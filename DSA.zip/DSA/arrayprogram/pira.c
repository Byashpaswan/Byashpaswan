#include<stdio.h>
int main()
{ int x=1,str,sp,row;
    int n=4;
    for(int row=1;row<=n;row++)
    {
        for(int sp=1;sp<=n-row;sp++)
            printf(" ");
        for(int str=1;str<=x;str++)
          printf("*");
      x=x+2;
    printf("\n");
   }
}