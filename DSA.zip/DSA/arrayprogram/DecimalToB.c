#include<Stdio.h>
#include<math.h>
#include<conio.h>
int main()
{
    int n;
    printf("Enter any number:");
    scanf("%d",&n);
    int ans=0;
    int i=0;
    while(n!=0)
    {
        int dig=n&1;
        ans=(dig* pow(10,i))+ans;
        n=n>>1;
        i++;

    }
    printf("After convert Binary:%d",ans);
    printf("\n");
    printf("%d",10&1);
}