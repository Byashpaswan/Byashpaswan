#include<stdio.h>
#include<stdlib.h>
void ToH(int ,char , char, char );
void main()
{ char source='A', desti='B', aux='c';
    int n=3;
    ToH(n,source,desti,aux);
    }
void ToH(int n,char source,char desti,char aux)
{   if(n==1)
      {  printf("%c-> %c ", source,desti);
           return ;
           }
    ToH(n-1,source,aux,desti);
        printf("\n%c->%c\n",source,desti);
        ToH(n-1,aux,desti,source);
    }