#include<stdio.h>
#include<string.h>
int main( ) 
/* { 
 char*c="GATECSIT2017"; 
 char* p=c; 
 printf("%d",(int)strlen(c+2[p]-6[p]-1));
 return 0; 
} */
//reversing string program
{  char str[20];
  int i=0,j,temp;
  printf("enter string\n");
  scanf("%s",str);
  j=strlen(str);
  while(i<j)
    { temp=str[i];
      str[i]=str[j];
      str[j]=temp;
      i++;
      j--;
    }
printf("%s",str[i]);
  }