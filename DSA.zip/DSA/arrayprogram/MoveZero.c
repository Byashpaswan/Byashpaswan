#include<stdio.h>

void print(int* arr,int n);
void MoveZero(int arr[],int size)
{
    for(int i=0;i<size;i++)
    {
        if(arr[i]==0)
        {                                  // Tc=O(n ^2)
            for(int j=i+1;j<size;j++)
            {
                if(arr[j]!=0)
                {
                  int temp=arr[i]; // swaping
                  arr[i]=arr[j];
                  arr[j]=temp;
                }
            }
        }
    }
}

void print(int arr[],int n)
{
    for(int i=0;i<n;i++)
     printf("%d ",arr[i]);
}

int main()
{
    int arr[]={0,2,5,0,10,0,20};
    int n=sizeof(arr)/sizeof(arr[0]);
    MoveZero(arr,n);
    print(arr,n);
  return 0;
}
/*  Optimized verson
void moveZero(int arr[],int size)
{
    int count=0;
    for(int i=0;i<n;i++)
    { 
        if(arr[i]!=0)
        {
           swap(arr[i],arr[count]);
           count++;
         }

    }              // TC=O(n);
}
*/