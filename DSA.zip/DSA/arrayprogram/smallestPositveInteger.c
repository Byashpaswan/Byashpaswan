#include<stdio.h>
int smallest_positive_integer(int arr[],int n);
int main()
{  int arr[]={1,3,4,5,10};
  int n=sizeof(arr)/sizeof(arr[0]);
   smallest_positive_integer(int arr[],int n)


}