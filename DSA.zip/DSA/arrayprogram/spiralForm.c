#include<stdio.h>
int main()
{ int arr[4][4],r=0,row=3,c=0,col=3,i,j,count=0;
printf("Enter arrays element\n");
for(i=0;i<4;i++){
   for(j=0;j<4;j++)
       scanf("%d",&arr[i][j]);
}

for(i=0;i<4;i++){
   for(j=0;j<4;j++)
      printf("%2d ",arr[i][j]);
      printf("\n");

    }
while(count<=16)
{ for(i=r;i<=col;i++)
      printf("%d ",arr[r][i]);
      count++;
  r++;
  for(i=r;i<=row;i++)
      printf("%d ",arr[i][col]);
   col--;
   count++;
  for(i=col;i>=c;i--)
      printf("%d ",arr[row][i]);
      row--;
      count++;

   for(i=row;i>=r;i--)
      printf("%d ",arr[i][c]);
      c++;
      count++;
   
}


}