#include<stdio.h>
int reverse(int a);
int main()
{
 int n;
 printf("Enter a number:");
scanf("%d",&n);
int l=reverse(n);
printf("%d",l);
return 0;

}
int reverse(int n)
{int ans=0,di;
  while(n!=0)
  {  di=n%10;
      ans=(ans*10)+di;
       n=n/10;
}
return ans;
}