#include<stdio.h>
int checkpalindrome(int);
int main()
{ int sum,n;
   printf("Enter a number\n");
   scanf("%d",&n);
   sum=checkpalindrome(n);
   if(n==sum)
      printf("%d is palindrome",n);
    else
       printf("%d is not palindrome",n);
    return 0;
}

 int checkpalindrome(int n)
{ static int sum=0,r;
  if(n!=0)
   { r=n%10;
     sum=sum*10+r; 
      checkpalindrome(n/10);
    }
    return sum;
}