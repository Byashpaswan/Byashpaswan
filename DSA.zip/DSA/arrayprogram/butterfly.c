#include<stdio.h>
int main()
{ int i,j,n;
  printf("enter the n value: ");
  scanf("%d",&n);
for(i=n;i>=1;i--)
    { for(j=n;j>=1;j--)
        { if(j>=i)
             printf("%d",j);
           else
               printf(" ");
        }
          for(j=2;j<=n;j++)
           {
              if(j>=i)
                 printf("%d",j);
              else
                 printf(" ");
        }
        printf("\n");
      }
      //down side
    for(i=2;i<=n;i++)
      { for(j=n;j>=1;j--)
           { if(j>=i)
               printf("%d",j);
              else
                 printf(" ");
            }
          for(j=2;j<=n;j++)
            {if(j>=i)
               printf("%d",j);
             else
               printf(" ");
            }
            printf("\n");
      }
  printf("\n");
}