#include<stdio.h>
#include<conio.h>  // strong no is factorial sum of its digit
int main()
{ int n,digit;
  printf(" Enter a number ");
   scanf("%d",&n);
   int a=n;
   int sum=0;
   while(n>0)
   { digit=n%10;
      n=n/10;
       
       int prod=1;
       for(int i=1;i<=digit;i++) // factorial of a digit
          prod=prod*i;
 sum=sum+prod;
   }
   if(sum==a)
   printf("%d is strong no\n",a);
 else
  printf("%d is not strong no\n ",a);

}