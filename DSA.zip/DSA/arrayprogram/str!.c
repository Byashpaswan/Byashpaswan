#include<stdio.h>
int main()
{ char arr[]="byas paswan";
char *ptr[3]={"devansh","ram","balaguruswanyji"};
printf("%s\n",arr);
printf("%s\n",&arr[0]);
printf("%s\n",arr+1);
printf("%c\n","hello/0"[6]);
printf("%s\n",ptr[0]);
printf("%s\n",*ptr);
printf("%s\n",ptr[0]+1);
printf("%s",ptr[2]);
}
