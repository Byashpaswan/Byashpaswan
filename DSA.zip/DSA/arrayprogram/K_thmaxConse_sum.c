#include<stdio.h>
int kthLargest(int Arr[],int N,int K){
        int arr_sum=0,i,MAXI;
        for(i=0;i<K;i++)
             arr_sum=arr_sum+Arr[i];
        int max_sum=arr_sum;
    
        for(i=K;i<N;i++)
        {
            arr_sum=arr_sum+(Arr[i]-Arr[i-K]);
            if(max_sum>arr_sum)
              MAXI=max_sum;
              
            else if(max_sum==arr_sum)
              MAXI=max_sum;
            else
            MAXI=arr_sum;
        }
        return MAXI;
    }
    int main()
    {
        
    }