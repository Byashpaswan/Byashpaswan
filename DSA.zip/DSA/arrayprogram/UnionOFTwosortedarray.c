#include<stdio.h>
int main()
{ int arr1[15],arr2[15],i,j,n,m;
printf("enter total no of element in array1 :");
scanf("%d",&n);
printf("Enter no element in second array");
scanf("%d",&m);
printf("Enter first array element ");
for(i=0;i<n;i++)
  { scanf("%d",&arr1[i]);
   }
printf("enter 2nd array element  ");
for(j=0;j<m;j++)
  { scanf("%d",&arr2[j]);
  }
  //sort array of first
  for(i=0;i<n-1;i++)
     { if(arr1[i]>arr1[i+1])
        {  int temp;
          temp=arr1[i];
          arr1[i]=arr1[i+1];
          arr1[i+1]=temp;
          }
     }
//sort seconsd array
for(j=0;j<m-1;j++)
 { if(arr2[j]>arr2[j+1])
      {  int swap;
         swap=arr2[j];
         arr2[j]=arr2[j+1];
         arr2[j+1]=swap;
         }
    }
//int i=0,j=0;
while(i<n&&j<m)
 {  if(arr1[i]<arr2[j])
      printf("%d",arr1[i++]);
    else if(arr2[j]<arr1[i])
         printf("%d",arr2[j++]);
    else
        {  printf("%d",arr2[j++]);
        i++;
        }
 }
 // print remaining elements of the larger array 
 printf(" remaining larger element ");
 while(i<n)
    printf("%d",arr1[i++]);
  while(j<m)
     printf("%d",arr2[j++]);
}