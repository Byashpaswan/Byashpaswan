#include<stdio.h>
#include<conio.h>
void Selection(int a[],int n)
{
    for(int i=0;i<n-1;i++)
    {     int temp;
        int min_index=i;
        for(int j=i+1;j<n;j++)
        {
            if(a[j]<a[min_index])
               min_index=j;
             
        }
     if(i!=min_index) 
        { temp=a[i];
          a[i]=a[min_index];
           a[min_index]=temp;
        }

    }
for(int k=0;k<n;k++)
    printf("%d",a[k]);
}
int main()
{int a[]={5,8,1,3,2};
 int n=sizeof(a)/sizeof(a[0]);
 Selection(a,n);
 

}