#include<stdio.h>
#include<conio.h>
void Bubble_sort(int a[],int n)
{    int flag=0;
    int pass,i,temp;
    for(pass=0;pass<n-1;pass++)
    {
        for(i=0;i<n-1-pass;i++)
        {
            if(a[i]>a[i+1])
            {   flag=1; 
                temp=a[i];
                a[i]=a[i+1];
                a[i+1]=temp;
            }
        }
        if(flag==0)
        break;
       
    }
    for(int i=0;i<n;i++)
     printf("%d",a[i]);
}

int main()
{
 int a[]={5,8,1,3,2,8,-1};
 int n=sizeof(a)/sizeof(a[0]);
 Bubble_sort(a,n);
 


}