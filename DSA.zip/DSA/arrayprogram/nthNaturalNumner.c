#include<stdio.h>
int nth_natural_number(int n)
{ int result=0;
  int p=1;
while(n>0)
   {  result+=(p*(n%9));
       n=n/9;
       p=p*10;
    }   
    return result;
}
int main()
{  int N=8;
   printf("\nnth natural number is %d\n ", nth_natural_number(N));
   return 0;
   }