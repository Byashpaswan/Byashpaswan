#include<stdio.h>
#include<conio.h> // basic two concept : 1: transpose,2:Reverse rowise
int main()
{
    int arr[3][3]={1,2,3,4,5,6,7,8,9};
    int i,j,k;
    for(i=0;i<3;i++)
    {
        for(j=i;j<3;j++)
        {                         // transpose of matrix
            int temp=arr[i][j];
            arr[i][j]=arr[j][i];
            arr[j][i]=temp;
        }

    }

    for(i=0;i<3;i++)  // reverse row wise like : 1 4 7 -> 7 4 1
    { k=2;
        for(j=0;j<k;j++)
        {  int temp=arr[i][j];
            arr[i][j]=arr[i][k];
            arr[i][k]=temp;
            k--;
        
        }
    
    }
    printf("After Rotate 90 degree\n");
    for(i=0;i<3;i++)
    {
        for(j=0;j<3;j++)
        {
            printf("%d ",arr[i][j]);
        }
         printf("\n");
    }

}