#include<stdio.h>
#include<conio.h>
int main()
{
    int arr[]={2,5,4,6,8,7,9};
    int n=sizeof(arr)/sizeof(arr[0]);
    int key,position;
    printf("Please Enter which position you wnat to insert a key ");
    scanf("%d",&position);
    printf("Enter a key you want to insert ");
    scanf("%d",&key);
    int index=position-1;
for(int i=n-1;i>index;i--)
   {  arr[i]=arr[i-1];
      

   }
   arr[index]=key;
   for(int j=0;j<n;j++)
   {
       printf("%d ",arr[j]);
   }

}