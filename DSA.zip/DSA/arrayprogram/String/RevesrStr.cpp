#include<bits/stdc++.h>
#include<iostream>
using namespace std;
string reverseByword(string s)
{
    vector<string>word;
    string str="";
    for(char c:s)
    {
        if(c==' ')
           {
            word.push_back(str);
            str="";
             }
        else
         str+=c;
    }

    word.push_back(str);
    int left=0;right=word.size()-1;

    while(left<=right)
    {
        swap(word[left],word[right]);
        left++;
        right--;
    }

    string ans="";
    for(auto x: word)
    {
        ans+=x;
        ans+=" ";
    }

    ans.pop_back();
    return ans;
}

int main()
{
    string s="This is a good day";
    reverseByword(s);
    for(int i=0;i<s.length(); i++)
    {
        cout<<s[i];
    }
}