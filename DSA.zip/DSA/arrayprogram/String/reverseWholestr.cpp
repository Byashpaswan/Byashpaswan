#include<bits/stdc++.h>
#include<iostream>
#include<string>
using namespace std;
void reverse(string &str,int low,int high)
{  while(low<=high)
    swap(str[low++],str[high--]);

}
void reversWord(string &str)
{    int n=str.length();
    int start=0,end;
    for(end=0;end<n;end++)
    { 
        if(str[end]==' ')
           {
            reverse(str,start,end-1);
            start=end+1;
           }

    }

    reverse(str,start,n-1);
    reverse(str,0,n-1);
}
int main()
{
    string s= "i love data structure";
    //int n=sizeof(s)/sizeof(s[0]);
    reversWord(s);
    return 0;
}
