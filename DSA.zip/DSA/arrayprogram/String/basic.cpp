#include<iostream>
using namespace std;
int length(char arr[])
{  int count=0;
    for(int i=0;arr[i]!='\0';i++)
    {
        count++;
    }
    return count;
}

void reverse(char arr[])
{
    int len=length(arr);
    int i=0;
    int j=len;
    while(i<j)
    {
        char temp=arr[i];
        arr[i]=arr[j];
        arr[j]=temp;
        i++;
        j--;
    }
}

int main()
{
    char arr[30];
    cout<<"Enter string\n";
   // cin>>arr;
   cin.getline(arr,30);
    cout<<"You entered :"<<arr;
    reverse(arr);
    cout<<arr;
    //cout<<"Length is "<<length(arr);
    return 0;
}