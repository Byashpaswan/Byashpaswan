#include<bits/stdc++.h>
#include<iostream>
using namespace std;

int main()
{
    string s="ABCABCD";
    string pat="ABCD";
    int n=s.length();
    int m=pat.length();

    for(int i=0;i<=n-m;i++)
    {   int j;
        for( j=0;j<m;j++)
        
            if(pat[j]!=s[i+j])
                break;
               
        
    

    if(j==m)
    cout<<i<<endl;
    }


}