#include<stdio.h>
int missing(int arr[],int n);
int main()
{  int arr[]={1,2,4,5,6,7,8,9,10};
int n=sizeof(arr)/sizeof(arr[0]);
printf("\n missing number is %d\n ",missing(arr,n));
return 0;
}

int missing(int arr[],int n)
{ int totalsum;
 int m=n+1;
 totalsum=m*(m+1)/2;
 int sum=0;
for(int i=0;i<n;i++)
   sum=sum+arr[i];
return totalsum-sum;

}
