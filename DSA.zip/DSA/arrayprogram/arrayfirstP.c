#include<stdio.h>
#include<conio.h>
int main()
/* {int a[4]={10,20,30,40};
 int*p[4]={a+3,a+2,a+1,a};
 int y;
 y=--p[0]-p[1];
 printf("%d\n",y);
 printf("%d",*p[0]);
 }  */
 {int a[5]={10,20,30,40,50};
 int *p,*q;
 p=&a[0];
 q=&a[3];
printf("%d %d\n",q-p,p-q);
}
