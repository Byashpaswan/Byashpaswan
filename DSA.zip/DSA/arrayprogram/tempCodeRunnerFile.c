
 printf("%d\n %s",l,str);
 }