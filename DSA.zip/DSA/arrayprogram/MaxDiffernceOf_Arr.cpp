#include<iostream>
#include<bits/stdc++.h>
using namespace std;
/*  arr[j]-arr[i]   where j>i
  arr[]={2,3,10,6,4,8,1};
  op->8
  i/p-> arr[]={7,9,5,6,3,2}
  o/p-> 2
  */

int maxDiff(int arr[],int n)
{
    int Mxelement=arr[1]-arr[0];
    int mini_element=arr[0];
    for(int i=1;i<n;i++)                   // Tc=O(N) and SC=O(1)
    {
        if(arr[i]-mini_element >Mxelement)
          Mxelement=arr[i]-mini_element;

        if(arr[i]<mini_element)
          mini_element=arr[i];
    }
    return Mxelement;

}
int main()
{
    int arr[]={2,3,10,6,4,8,1};
    int n=sizeof(arr)/sizeof(arr[0]);
     cout<<"Maximum diff is =\n "<<maxDiff(arr,n);
  return 0;
}