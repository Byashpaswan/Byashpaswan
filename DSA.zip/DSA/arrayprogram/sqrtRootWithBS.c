#include<stdio.h>
int BinarySearch(int n)
{
   int s=0,end=n;
   int mid=s+(end-s)/2;
   int ans=-1;
   while(s<=end)
   {
       int square=mid*mid;
       if(square==n)
          return mid;
        if(square<n)
           { ans=mid;
              s=mid+1;

            }
        else
           {
             end=mid-1;  
           }
      mid=s+(end-s)/2;
   } 
   return ans;

 }
 int main()
   {
     int n;
     printf("Enter any number\n");
     scanf("%d",&n);
     printf("squre root of  %d-> is  %d", n,BinarySearch(n));
     }

