#include<stdio.h>
int main()
{ 
    int n,i=1;
    printf("Enter a number ");
    scanf("%d",&n);
    while(i<=n)
    {
        int j=1;
        int p=i;
        while(j<=i)
        {
            printf("%d",p);
            p++;
            j++;
        }
        printf(" ");
        i++;
        printf("\n");
    }
    return 0;
}