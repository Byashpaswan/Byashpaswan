#include<stdio.h>
int main()
{
    int n,i=1;
    printf("Enter any no ");
    scanf("%d",&n);

    while(i<=n)
    {
        int j=1;
        while(j<=n)
        {
         printf("*");
         j++;  
        }
        printf("\n");
        i++;
    }
}