#include<stdio.h>
#include<conio.h>
void merge(int A[],int B[],int C[],int m,int n)
{
    int i=0,j=0,k=0;
    while(i<m && j<n)
    {
        if(A[i]<B[j])
            C[k++]=A[i++];
        
        else
            C[k++]=B[j++];

    }
    while(i<m)
      C[k++]=A[i++];
    while(j<n)
       C[k++]=B[j++];
       printf("After merge two array \n");
    for(int i=0;i<m+n;i++)
        printf("%d ",C[i]);
    printf("\n");
}
int main()
{
    int Arr[]={1,3,8,10};
    int arr2[]={2,4,5,6,9,12};
    int m=sizeof(Arr)/sizeof(Arr[0]);
    int n=sizeof(arr2)/sizeof(arr2[0]);
    int arr3[m+n];
    merge(Arr,arr2,arr3,m,n);
    return 0;

}