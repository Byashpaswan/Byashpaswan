#include<stdio.h>
int equilibrium_point(int arr[],int n)
 { int leftsum=0,sum=0,i;
    for(i=0;i<n;i++)
       sum=sum+arr[i];

    for(i=0;i<n;i++)
     {  sum-=arr[i];
        if(leftsum==sum)
           return i;
       leftsum=leftsum+arr[i];
     }
     return -1;
}

int main()
  { int arr[]={-7,1,5,2,-4,3,0};
     int n=sizeof(arr)/sizeof(arr[0]);
     printf("Equilibrium point is %d ", equilibrium_point(arr,n));
     return 0;
}