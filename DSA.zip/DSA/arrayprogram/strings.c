#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main()
{int l,count;
 char *ptr="byaspaswan";
 l=strlen(ptr);
 printf("%d",l);
}

   /*count=0;
 while(ptr!='\0')
 { ptr++;
   count++;
 }
 l=count;
 printf("length is %d",l);
 return 0;
}*/