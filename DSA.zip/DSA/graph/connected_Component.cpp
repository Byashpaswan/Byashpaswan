#include<iostream>
#include<bits/stdc++.h>
using namespace std;
int bfsOfGraph(int v,vector<int>adj[])
{
    vector<int>bfs;
    int vis[v+1]={0};
    int count=0;
    for(int i=1;i<=v;i++)
   {
       if(vis[i]==0)
       {  count++;
           queue<int>q;
           q.push(i);
            vis[i]=1;
           while(!q.empty())
          {
              int node=q.front();
              q.pop();
              bfs.push_back(node);
              for(auto it: adj[node])
               {
                    if(vis[it]==0)
                  {
                       q.push(it);
                     vis[it]=1;
                   }
                }
            } 
        }
    }


  return count;

}

int main()
{
    int n,m;
    cout<<"Enter the no of node in graph"<<endl;
    cin>>n;
    cout<<"Enter the no of edge in graph"<<endl;
    cin>>m;

    vector<int>adj[n+1];
    for(int i=0;i<m;i++)
    {
        int u,v;
        cin>>u>>v;
        adj[u].push_back(v);
        adj[v].push_back(u);
    }

    //vector<int>ans=bfsOfGraph(n,adj);
    int cnt=bfsOfGraph(n,adj);
    if(cnt>1)
    cout<<"Disconnected graph "<<endl;
    
    cout<<"No of connected component is "<<cnt<<endl;

    return 0;
}