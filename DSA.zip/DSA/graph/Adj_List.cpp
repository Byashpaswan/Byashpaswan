#include<bits/stdc++.h>
#include<iostream>
using namespace std;
int main()
{
    int n,m;
    cout<<"Enter the no of node in graph"<<endl;
    cin>>n;
    cout<<"Enter the no of edge in graph"<<endl;
    cin>>m;
    vector<int>adj[n+1];
    for(int i=0;i<m;i++)
    {
        int u,v;
        cin>>u>>v;
        // undirected edges
        adj[u].push_back(v);
        adj[v].push_back(u);
    }
    cout<<"Adjecency List"<<endl;
    for(int i=1;i<=n;i++)
    {
        cout<<i<<"-->"<<" ";
        for(auto it: adj[i])
           cout<<it<<" ";
        cout<<endl;
    }
    return 0;

}