#include<iostream>
#include<bits/stdc++.h>
using namespace std;
int main()
{   int n,m;
    cout<<"Enter no of Node in graph"<<endl;
    cin>>n;
    cout<<"Enter the no of edge in graph "<<endl;
    cin>>m;
    int adj[n+1][n+1]={0};
    for(int i=0;i<m;i++)
    {
       int u,v;
       cin>>u>>v;
       adj[u][v]=1;
       adj[v][u]=1;
    }
cout<<"Adjecency Matrix"<<endl;
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
          {
            cout<< adj[i][j]<<" ";
          }
          cout<<endl;
    }

}