#include<stdio.h>
#include<stdlib.h>
struct BstNode
{
    int data;
    struct BstNode* left;
    struct BstNode* right;
};

//create new node 
struct BstNode* newnode(int data)
{
    struct BstNode* t=(struct BstNode*)malloc(sizeof(struct BstNode));
    t->data=data;
    t->left=t->right=NULL;
    return t;
}

struct BstNode* creat(struct BstNode* head,int data)
{
    if(head==NULL)
    {
        head=newnode(data);
         return head;
    }
    else if(data<=head->data)
       head->left=creat(head->left,data);
    else
         head->right=creat(head->right,data);
    return head;
}
// traversal 

void inorder(struct BstNode* head)
{
    if(head!=NULL)
    {
        inorder(head->left);
        printf("%d\n",head->data);
        inorder(head->right);
    }
}

int main()
{
    struct BstNode* head=NULL;
    head=creat(head,10);
    head=creat(head,20);
    head=creat(head,30);
    head=creat(head,40);
    head=creat(head,60);
    head=creat(head,80);
    inorder(head);
    return 0;
}