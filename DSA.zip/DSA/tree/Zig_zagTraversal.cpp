#include<bits/stdc++.h>
#include<iostream>
using namespace std;
// Binary tree node
class Node{
    public:
    int data;
    Node *left, *right;
};
// function to print zig zag
vector<int> zigzagTraversal(Node* root)
{
    if(root==NULL)
       return  { };

    vector<int>ans;
    queue<Node*>q;
    q.push(root);
    bool flag=false;
    while(!q.empty())
    { int size=q.size();
       vector<int>level;

       for(int i=0;i<size;i++)
       {
         Node* frontNode=q.front();
           q.pop();

         level.push_back(frontNode->data);
         if(frontNode->left!=NULL)
             q.push(frontNode->left);
         if(frontNode->right!=NULL)
           q.push(frontNode->right);

        }

       flag=!flag;
       if(flag==false)
         reverse(level.begin(), level.end());

       for(int i=0;i<level.size();i++)
           ans.push_back(level[i]);

    }

    return ans;
}

// a utility function to create a new node
struct Node* newnode(int data)
{
    struct Node* node=new struct Node;
    node->data=data;
    node->left=node->right=NULL;
    return (node);
}

int main()
{
    vector<int>v;
    // create tree
    struct Node* root=newnode(1);
    root->left=newnode(2);
     root->right=newnode(3);
     root->left->left=newnode(7);
    root->left->right=newnode(6);
     root->right->left=newnode(5);
      root->right->right=newnode(4);

      cout<<" Zigzag traversal \n   ";

   v=zigzagTraversal(root);
   for(int i=0;i<v.size();i++)
   {
    cout<<v[i]<<" ";
   }
 return 0;

}