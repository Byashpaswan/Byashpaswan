#include<iostream>
#include<queue>
using namespace std;
class Node
{ public:
    int data;
    Node* left;
    Node* right;

Node(int d)
   {
    this->data=d;
    this->left=NULL;
    this->right=NULL;
    }
};

Node* creatNode(Node* root)
{
    cout<<" Enter the data of the Node "<<endl;
    int data;
    cin>>data;
    root=new Node(data);
    if(data==-1)
       return NULL ;

    cout<<" Enter the data for left  of :"<< data <<endl;
    root->left=creatNode(root->left);
    cout<<" Enter the data for right of :"<<data <<endl;
    root->right=creatNode(root->right);
    return root;
}

void LevelOrderTravrs(Node* root)
{
    queue<Node*>q;
    q.push(root);
    q.push(NULL);

    while(!q.empty())
     { Node* temp=q.front();
       
       q.pop();

    if(temp==NULL)
    {
        // purana level complete ho chuka hai 
        cout<<endl;

        if(!q.empty())
          {   // queue has some child nodes
            q.push(NULL);
           }
      }

   else{
          cout<<temp->data<<" ";
           if(temp->left)
           {
             q.push(temp->left);
               }
        
         if(temp->right)
           { 
            q.push(temp->right);
           }

        }
    }
}

void inorder(Node* root)
{
    if(root==NULL)
      return ;
   inorder(root->left);
   cout<<root->data<<" ";
   inorder(root->right);
}

void preorder(Node* root)
{
    if(root==NULL)
      return ;
   
   cout<<root->data<<" ";
   preorder(root->left);
   preorder(root->right);
}
void postorder(Node* root)
{
    if(root==NULL)
      return ;
   postorder(root->left);
   
   postorder(root->right);
   cout<<root->data<<" ";
}

void buildFromlevelOtr(Node* &root)
{
    queue<Node*>q;
    
    cout<< " enter data for root "<<endl;
    int data;
    cin>>data;
    root=new Node(data);
    q.push(root);

    while(!q.empty())
    {
        Node* temp=q.front();
        q.pop();

        cout<<" enter left node for :"<< temp->data<<endl;
        int leftdata;
        cin>>leftdata;

        if(leftdata!=-1)
        {
            temp->left=new Node(leftdata);
            q.push(temp->left);

        }
        cout<<" enter Right  node for :"<< temp->data<<endl;
        int rightdata;
        cin>>rightdata;

        if(rightdata!=-1)
        {
            temp->right=new Node(rightdata);
            q.push(temp->right);

        }


    }
}
int main()
 {
    Node* root=NULL;
   /* root=creatNode(root);

    // level order traverasal
    // 1 3 7 -1 -1 11 -1 -1 5 17 -1 -1 -1
    cout<<" print level order traversal output:"<<endl;
    LevelOrderTravrs(root);
    // inorder traversal 
    cout<< " Inorder traversal "<<endl;

    inorder(root);
    cout<<"preorder travesal ";
    preorder(root);   // preorder
    cout<<"post order"<<endl;
    postorder(root);  // post order
    */
   buildFromlevelOtr(root);
   LevelOrderTravrs(root);

    return 0;
 }