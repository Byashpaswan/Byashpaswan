#include<stdio.h>
int main()
{
    int n,i,sum;
    //printf("Enter no ");
    //scanf("%d",&n);
    for(n=4;n<=100;n++)
    { sum=0;
      for(i=1;i<=n-1;i++)
      {
          if(n%i==0)
        
            sum=sum+i;
        
       }
    if(sum==n)
    printf("the nomber is %d perfect number\n",n);
    }
}