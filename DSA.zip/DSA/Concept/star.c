#include<stdio.h>
int main()
{
  int  row,col;
  for(row=1;row<=5;row++)
  {
    for(col=1;col<=row;col++)
        printf("*");
     printf("\n");
  }
 
  printf("-------------------------------------------\n");

  for(row=1;row<=5;row++)
  {
    for(col=1;col<=6-row;col++)   /// col<=n+1-row;
     printf("*");
     printf("\n");
  }

  printf("-------------------------------------------------\n");

  for(row=1;row<=5;row++)
  {
   
      for(int space=1;space<=5-row;space++)
           printf(" ");
      for(int star=1;star<=row;star++)
         printf("*");

        printf("\n");
       

       
      }
       
  }
