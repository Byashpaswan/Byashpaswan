#include<stdio.h>
int main()
{
    int row,space,x=1,star;
    for(row=1;row<=4;row++)
    {
       
        for(space=1;space<=4-row;space++)
             printf(" ");


      for(star=1;star<=x;star++)
          printf("*");
    printf("\n");
    x=x+2;
    }
    return 0;
}