#include<iostream>
using namespace std;

bool isSafe(int row,int col,int n,int arr[][20],int vis[][20])
{
    if((row>=0 && row<n)&& (col>=0 && col<n) && (arr[row][col]==1) &&(vis[row][col]!=1))
       return true;

 return false;
}


void solve(int ro,int col,int n,int arr[][20],int vis[][20])
{
    if(ro==n-1 && col==n-1)
      { vis[ro][col]=1;

       for(int i=0;i<n;i++)
       {
        for(int j=0;j<n;j++)
          {
            cout<<vis[i][j]<<" ";
          }
          cout<<endl;
       }
      cout<<"\n";
      vis[ro][col]=0;
      }

      // Down
  if(isSafe(ro+1,col,n,arr,vis))
  {
    vis[ro][col]=1;
    solve(ro+1,col,n,arr,vis);
    vis[ro][col]=0;/// for Backtracking
  }

  //Upward
  if(isSafe(ro-1,col,n,arr,vis))
  {
    vis[ro][col]=1;
    solve(ro-1,col,n,arr,vis);
    vis[ro][col]=0;// Backtracking

  }

  // Right
  if(isSafe(ro,col+1,n,arr,vis))
  {
    vis[ro][col]=1;
    solve(ro,col+1,n,arr,vis);
    vis[ro][col]=0;// Backtracking
  }

  // left
  if(isSafe(ro,col-1,n,arr,vis))
  {
    vis[ro][col]=1;
    solve(ro,col-1,n,arr,vis);
    vis[ro][col]=0; // backtracking
  }
}
int main()
{  int n=4;
    int arr[20][20]={ {1,0,0,0},
                      {1,1,0,0},
                      {1,1,0,0},
                      {0,1,1,1}
                    };
                    
    int vis[20][20]={0};
    if(arr[0][0]==0)
       return 0;
       if(arr[n-1][n-1]==0)
       return 0;

    solve(0,0,n,arr,vis);
    return 0;
}

/*
Complexity Analysis: 

Time Complexity: O(2^(n^2)). 
The recursion can run upper-bound 2^(n^2) times.
Space Complexity: O(n^2). 
Output matrix is required so an extra space of size n*n is needed.*/