#include<iostream>
#include<bits/stdc++.h>
using namespace std;


int Lcs(char* X,char * Y,int m,int n)
{  int i,j;
   int L[m+1][n+1];
  for( i=0;i<m;i++)
    L[i][0]=0;
 for(i=0;i<n;i++)
      L[0][i]=0;

for(i=1;i<m;i++)   // row wise value fullfils
{
    for(j=1;j<n;j++)
    {
        if(X[i-1]==Y[j-1])
          L[i][j]=1+L[i-1][j-1];
        else
           L[i][j]=max(L[i][j-1],L[i-1][j]);

    }
}
return L[m][n];

}

int main()
{
    char X[]= "AGGTAB";
    char Y[]="GXTXAYB";
    int m=X.lenght();
    int n=Y.length()
      cout<<( Lcs(X,Y,m,n));

      
    return 0;
}