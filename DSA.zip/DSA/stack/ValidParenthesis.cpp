#include <bits/stdc++.h>
#include<iostream>
using namespace std;
bool isBracketValid(string exp )
{
    stack<char>s;
    for(int i=0;i<exp.length();i++)
    {
        if(s.empty())
          {
            s.push(exp[i]);
            }

      else if ((s.top()=='(' && exp[i]==')')|| (s.top()=='{'&& exp[i]=='}')||(s.top()=='['&& exp[i]==']'))
           {
              s.pop();
            }

         else
            s.push(exp[i]);

     if(s.empty())
      return true;
    }

    return false;
}
int main()
{
    string st="[{()}]";

     if (isBracketValid(st))
        cout << "Balanced"<<"\n";
    else
        cout << "Not Balanced"<<"\n";
    return 0;
}