#include<iostream>
#include<stack>
using namespace std;
int main()
{
    stack<int>s;

    // push operation
    s.push(10);
    s.push(30);
    s.push(40);

    // pop operation
    s.pop();
    
    cout<<"printing top element "<<s.top()<<"\n";

    if(s.empty())
    
        cout<<" stack is empty ";
    else
      cout<<" stack is not empty ";

      // size 

 cout<< " \n size of stack is "<< s.size();
    return 0;
}