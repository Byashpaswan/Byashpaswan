#include<bits/stdc++.h>
#include<iostream>
using namespace std;
stack<int>st;
void insert_At_CorrectPos(int x)
{
    if(st.size()==0 || st.top()<x)
       st.push(x);
    else
      {
        int a=st.top();
        st.pop();
        insert_At_CorrectPos(x);
        st.push(a);
      }
}

void reverse()
{
    if(st.size()>0)
    {
        int x=st.top();
        st.pop();
        reverse();
        insert_At_CorrectPos(x);
    }
}
int main()
{
    st.push(11);
    st.push(2);
    st.push(32);
    st.push(3);
    st.push(41);
     reverse();
     while(!st.empty())
     {
        cout<<st.top()<<" ";
        st.pop();
     }

     return 0;

}