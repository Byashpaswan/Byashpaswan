#include<iostream>
using namespace std;
void insertAtBot(stack<int>&s,int element)
{
    if(s.empty())
     {
        s.push(element);
        return;
       }
    int num=s.top();
       s.pop();
       // recursive call
    insertAtBot(s,element);

    s.push(num);

}

void reverseStack(stack<int>&st)
{
    // base case
    if(st.empty())
    {
        return;
    }
    int num=st.top();
    stack.pop();
    // recursive call
    insertAtBot(stack.num);

}

int main()
{
    stack<int>st;
    st.push(2);
    st.push(3);
    st.push(5);
    st.push(7);
    st.push(9);

while(!st.empty())
     {
        int d=st.top();
         st.pop();
       cout<< d<<" ";
     }
     return 0;
}
