#include<bits/stdc++.h>
#include<iostream>
using namespace std;
int main()
{
    int arr[]={10,4,2,20,40,12,30};
    int n=7;

    stack<int>s;
    s.push(arr[0]);
    cout<<"-1"<<" ";
    for(int i=1;i<n;i++)
    {
        while(s.empty()==false && s.top()<=arr[i])
         s.pop();

         int prev=(s.empty())? -1: s.top();

         cout<<prev<<" ";

         s.push(arr[i]);
    }

 return 0;
}
