#include<iostream>
#include<stack>
using namespace std;
class Stack
{
    // property
    public:
    int *arry;
    int top;
    int size;

    // Behaviour
    Stack(int size)
    {
        this->size=size;
        arry=new int[size];
        top=-1;
    }

    void Push(int element)
    { if(size-top>1)
         {
           top++;
           arry[top]=element;
          }
        else
        {
           cout<<"stack over flow "<<endl;
        }

    }

    void Pop()
    { 
        if(top>=0)
    
            top--;
        else
         cout<< " stack under flow ";

    }

    int Peek()
    {
        if( top>=0)
          return arry[top];

        else
         { 
            cout<<"stack is empty";
             return -1;
         }

    }

    bool isEmpty()
    {  
        if(top==-1)
         return true;
        else
          return false;

      }
};

int main()
{  Stack st(5);
     st.Push(10);
     st.Push(20);
     st.Push(30);
    st .Push(40);
     st.Push(5);
        
          
      st.Pop();
     cout<< st.Peek()<<"\n";
     cout<<" size of stack is "<<st.size;
     if(st.isEmpty())
       cout<<" \nstack is not empty";
    else
      cout<<" \nstack is not empty";
}

