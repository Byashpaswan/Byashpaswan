#include <iostream>
 #include<bits/stdc++.h>
using namespace std;

void solve(stack<int>&s, int count , int stacksize)
  {
    if (count == stacksize/2)
    {
        s.pop();
        return;
    }

    int num = s.top();
    s.pop();

        // recursive call

  solve(s,count + 1, stacksize);
            s.push(num);
}

void DelMiddle(stack<int>&s,int stacksize)
  {
    int count = 0;
    solve(s, count, stacksize);
    }


   

int main()
{  // push element in stack
    stack<int>st;
    st.push(1);
    st.push(2);
    st.push(3);
    st.push(4);
    st.push(5);
    st.push(6);

    DelMiddle(st,st.size());
    
    // Printing stack after deletion
    // of middle.

     while(!st.empty())
     {
        int d=st.top();
         st.pop();
       cout<< d<<" ";
     }
     return 0;
}
