#include<stdio.h>
int main()
{
    int n=8;
    if(n%2!=0)
      printf("werd");
   else
    {
       if((n%2==0)&&(n>=2&&n<=5)) 
         printf(" not werd");
       else if((n%2==0)&&(n>=6 && n<=20))
          printf("Werd");
     else
         printf(" not werd");
        }
}