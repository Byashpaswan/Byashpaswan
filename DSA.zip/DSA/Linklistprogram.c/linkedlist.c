#include<stdio.h>
#include<stdlib.h>
struct node{
    int data;
    struct node*link;
}*start=NULL;

void creatnodelist(int n)
 {  struct node*newnode,*temp;
   int num,i;   
   start=(struct node*)malloc(sizeof(struct node));
   if(start==NULL)
      printf("Memory cant be allocated :");
   else
    { printf("input data for node :");
       scanf("%d",&num);
       start->data=num;
        start->link=NULL;
       temp=start;
    // creating n nodes and add into link list
       for (i=2;i<=n;i++)
         { newnode=(struct node*)malloc(sizeof(struct node));
    
           if(newnode==NULL)
             { printf("Memeory is not allocated ");
               break; 
            }
          else
            {  printf("input data for a node %d ",i);
             scanf("%d",&num);
             newnode->data=num;
             newnode->link=NULL;

             temp->link=newnode;
             temp=temp->link;
           }
       }
    }
}
  void display()
    { struct node *temp;
    if(start==NULL) 
        printf("Linked list is not exsitst");
    else
    {
       temp=start;
       while(temp!=NULL)
       {  printf("data= %d\n",temp->data);
         temp=temp->link;
        }
    }
 
    
}
int main()
{
   int n;
   printf("Enter no of nodes :");
   scanf("%d",&n);
    creatnodelist(n);
    printf("\n entered data is ");
    display();
    return 0;
}

