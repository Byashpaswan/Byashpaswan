#include<bits/stdc++.h>
#include<iostream>
using namespace std;
class Node{
     public:
     int data;
     Node* next;
     Node(int a)
     {
        data=a;
        next=NULL;
     }

};
void insertNode(Node* &head,int data)
{  Node* newnode=new Node(data);
    if(head == NULL) {
        head = newnode;
        return; 
    }
    Node* temp = head;
    while(temp->next != NULL) 
        temp = temp->next;
    
    temp->next = newnode;
    return;
}

Node* rotate_rightByK(Node* head,int k)
{
    if(!head||!head->next||k==0)
      return head;
    Node* temp=head;
    int len=1;
    while(temp->next!=NULL)
     { ++len;
       temp=temp->next;
     }
     temp->next=head;
     k=k%len;
     int end=len-k;
     while(end--)
       temp=temp->next;
 //breaking last node link and pointing to NULL
    head=temp->next;
    temp->next=NULL;

    return head;
}
//utility function to print list
void printList(Node* head) {
    while(head->next != NULL) {
        cout<<head->data<<"->";
        head = head->next;
    } 
    cout<<head->data<<endl;
    return;
}
int main() {
    Node* head = NULL;
    //inserting Node
    insertNode(head,1);
    insertNode(head,2);
    insertNode(head,3);
    insertNode(head,4);
    insertNode(head,5);
    
    cout<<"Original list: ";
    printList(head);
    
    int k = 5;
    Node* newHead = rotate_rightByK(head,k);//calling function for rotating right of the nodes by k times
    
    cout<<"After "<<k<<" iterations: ";
    printList(newHead);//list after rotating nodes
    return 0;
}