#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
struct node
{
    int data;
    struct node *Link;
};
void Insert_at_Big(struct node **ptr , int key)
{
   struct node* temp=(struct node*)malloc(sizeof(struct node));
    
    temp->data=key;
    temp->Link=*ptr;
    *ptr=temp;
    
}
void specific_Posi(struct node* pre_node,int key)
{
    if(pre_node==NULL) 
      {
        printf("the previous node canot null");
        return;
      }
    struct node *new_node=(struct node*)malloc(sizeof(struct node));
    new_node->data=key;
    new_node->Link=pre_node->Link;
    pre_node->Link=new_node;
 }
void printList(struct node* node)
{ while(node!=NULL)
   {
      printf("%d ",node->data );
      node=node->Link;
    }
}
  void insert_at_end(struct node **h_refe,int key)
  {
      struct node* new_node=(struct node*)malloc(sizeof(struct node));
        new_node->data=key;
       new_node->Link=NULL;
      while(*h_refe==NULL)
      { *h_refe=new_node;
          return;
        }
      struct node *ptr= *h_refe;
      while(ptr->Link!=NULL)
          { ptr=ptr->Link;
            }
       ptr->Link=new_node;
       return;
  }


int main()
{struct node* start=NULL;
 Insert_at_Big(&start,110);
 Insert_at_Big(&start,200);
 Insert_at_Big(&start,400);
 insert_at_end(&start,7);
 specific_Posi(start->Link,8);
 printf("After execution Linked list like this:\n\n");
 printList(start);
 printf("\n\n");
 return 0;

}