#include<stdio.h>
#include<stdlib.h>
struct node *insert_At_begning(struct node*,int);
struct node{
    int data;
    struct node *link;
};
int main()
{int key=3;
struct node *start=(struct node*)malloc(sizeof(struct node));
start->data=10;
start->link=NULL;

struct node *ptr;
ptr=(struct node*)malloc(sizeof(struct node));
ptr->data=20;
start->link=ptr;
ptr->link=NULL;
start=insert_At_begning(start,key);
ptr=start;
while(ptr!=NULL)
{ printf("%d ",ptr->data);
  ptr=ptr->link;
}
}
struct node* insert_At_begning(struct node *temp,int d)
{ struct node *ptr=(struct node*)malloc(sizeof(struct node));
ptr->data=d;
ptr->link=temp;
return ptr;
 }




