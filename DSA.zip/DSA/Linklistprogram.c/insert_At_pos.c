#include<stdio.h>
#include<stdlib.h>
struct node* insert_At_pos(struct node* start,int data);
struct node{
    int data;
    struct node* link;
};
int main()
{  struct node* start=(struct node*)malloc(sizeof(struct node));
  start->data=40;
  start->link=NULL;
  struct node*ptr=start;                }