#include<stdio.h>
#include<stdlib.h>
struct node
{
    int data;
    struct node* link;
};
 void creatNewNode()
 {
    struct node* newnode=(struct node* )malloc(sizeof(struct node));
    newnode->data=data;
    newnode->link=NULL;
    if(head==NULL)
    { newnode->link=head;
      head=newnode;

    }
    struct node*ptr=head;
    while(ptr->link!=NULL)
    {
        ptr=ptr->link;
    }
    ptr->link=newnode;
 }


void printnode(struct node* *head)
{
    struct node* ptr=head;
    while(ptr!=NULL)
    {
        printf("%d ", ptr->data);
        ptr=ptr->link;

    }
}


int main()
{  
    struct node head=NULL;
    int n,data;
    printf("Enter  no of node you want to \n");
    scanf("%d",&n);
    printf("insert %d node ");

    for(int i=0;i<n;i++)
    {   scanf("%d",&data);
        creatNewNode(head,data);
    }

    printnode(head);
}