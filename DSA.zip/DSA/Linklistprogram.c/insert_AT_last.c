#include<stdio.h>
#include<stdlib.h>
struct node *insert_at_last(struct node* start,int key);

struct node{
    int data;
    struct node* link;
};

int main()
{ struct node* start=(struct node*)malloc(sizeof(struct node));
   start->data=45;
   start->link=NULL;
   struct node* ptr=start;
   ptr=insert_at_last(ptr,50);
   ptr=insert_at_last(ptr,60);
   ptr=insert_at_last(ptr,70);
   ptr=start;
   while(ptr!=NULL){
      printf("%d ",ptr->data);
      ptr=ptr->link;
     }  
  return 0;    
}

struct node* insert_at_last(struct node* start,int data)
{ struct node* temp=(struct node*)malloc(sizeof(struct node));
 struct node *ptr;
 ptr=start;
 temp->data=data;
 temp->link=NULL;
while(ptr->link!=NULL)
     ptr=ptr->link;
ptr->link=temp;
return ptr;
 

   }



