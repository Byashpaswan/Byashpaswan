import java.util.*;
public class charTrinanglePtrn {
    public static void main(String args[])
    { Scanner s=new Scanner(System.in);
        int n=s.nextInt();
        char c='A';
        int i=1;
        while(i<=n)
        {
         int j=1;
        while(j<=n);
        { char val=(char)('A'+i);
         System.out.print("A");
           j++;
         }
         System.out.println();
            i++;

        }
    }
    
}
