import java.util.*;
 public class claa { 
    public static void main(String args[]) {
        Scanner s1=new Scanner(System.in);
        System.out.println("Enter the number");
        int n=s1.nextInt();

        System.out.println("Enter double ");
        double dp=s1.nextDouble();

        System.out.println("integer :" + n);
        System.out.println("double :" + dp);
    }
}
