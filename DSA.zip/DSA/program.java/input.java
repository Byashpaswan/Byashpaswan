import java.util.*;
public class input{
public static void main(String args[]){
    Scanner sc=new Scanner(System.in);
    System.out.println("input a number");
    int x=sc.nextInt();
    System.out.println("Enter another number");
    int y=sc.nextInt();
    System.out.println("now sum of two number");
    int z=x+y;
    System.out.println("sum"+z);
}


}

