public class add {
    public static void main(String arg[])
    {
        int x,y,z;
        x=5;
        y=6;
        z=x+y;
        System.out.println("value of :"+z);
        }
}
