import java.util.*;
import java.lang.Math;
public class calulater {
    public static void main(String args[])
    {   int a,b,result;
        char ch;
        Scanner sc=new Scanner(System.in);
        System.out.println(" Enter a number:");
        a=sc.nextInt();
        System.out.println(" Enter any operator u want such as (+,-,*,/):");
        ch=sc.next().charAt(0);
        System.out.println(" Enter second  number:");
        b=sc.nextInt();
        switch(ch)
        { case '+': 
               result=a+b;
               System.out.println("your ans is =" +result);
                break;
          case '-':
                  result=Math.abs(a-b);
                  System.out.println("your ans is =" +result);
                  break;
           case '*':
                result=a*b;
                System.out.println("your ans is = " +result);
                break;
            case '/':
                  result=a/b;
                  System.out.println("your ans is = " +result);
                  break;
            default :
                   System.out.println("Invailid input");
                   break;


           }


    }
    
}
