public class calcu {
    public static void main(String args[])
    {
        double a=55.55;
        int b=55;
        a=a%10;
        b=b%10;
        System.out.println(a+" "+b);

    }
    
}
