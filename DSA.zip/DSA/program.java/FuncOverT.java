import java.util.Scanner;
public class FuncOverT {
    public static int sum(int a,int b)
    { int c=a+b;
        return c;
        
    }
    public static double sum(double c,double d)
    {
        return c+d;
    }
    public static void main(String args[])
    {
        Scanner s=new Scanner(System.in);
        int a=6;
        int b=10;
        System.out.println(sum(a,b));
        System.out.println(sum(10.5,20.5));

    }
}
