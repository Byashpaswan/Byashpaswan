import java.util.*;
public class charecterpatrn {
    public static void main(String args[])
    { Scanner s =new Scanner(System.in);;
        int n=s.nextInt();
        int i=1;
        while(i<=n)
        { 
            int j=1;
            while(j<=n)
            {
         char c=(char)('A'+j-1);
         System.out.print(c);
         j=j+1;
            }
          System.out.println(" ");
          i++;  
        }


    }
    

}
