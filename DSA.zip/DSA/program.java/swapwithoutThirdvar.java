import java.util.*;
public class swapwithoutThirdvar {
    public static void main(String args[])
    {  int a,b;
        Scanner cs=new Scanner(System.in);
        System.out.println("Enter the value of a and b :");
        a=cs.nextInt();
        b=cs.nextInt();
        a=a+b;
        b=a-b;
        a=a-b;
        System.out.println("value of a : " +a);
        System.out.println("value of b : " +b);


    }
    
}
